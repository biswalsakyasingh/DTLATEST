// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Azure.DigitalTwins.Samples.models;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using YamlDotNet.Serialization;

namespace Microsoft.Azure.DigitalTwins.Samples
{
    public static partial class Actions
    {
        // Prints out and returns spaces with the occupany property key set
        public static async Task GetAvailableAndFreshSpaces(HttpClient httpClient)
        {
            Console.WriteLine("Polling spaces with 'AvailableAndFresh' value type");

            var maxGets = 30;
            for (var curGets = 0; curGets < maxGets; ++curGets)
            {
                var (spaces, response) = await GetManagementItemsAsync<Models.Space>(httpClient, "spaces", "includes=values");
                if (spaces == null)
                {
                    var content = await response.Content?.ReadAsStringAsync();
                    Console.WriteLine($"ERROR: GET spaces?includes=values failed with: {(int)response.StatusCode}, {response.StatusCode} {content}");
                    break;
                }

                var availableAndFreshSpaces = spaces.Where(s => s.Values != null && s.Values.Any(v => v.Type == "AvailableAndFresh"));
                if (availableAndFreshSpaces.Any())
                {
                    var availableAndFreshDisplay = availableAndFreshSpaces
                        .Select(s => GetDisplayValues(s))
                        .Aggregate((acc, cur) => acc + "\n" + cur);
                    Console.WriteLine($"{availableAndFreshDisplay}");
                }
                else
                {
                    Console.WriteLine("Unable to find a space with value type 'AvailableAndFresh'");
                }

                await Task.Delay(TimeSpan.FromSeconds(4));
            }
        }

        private static async Task<(IEnumerable<T>, HttpResponseMessage)> GetManagementItemsAsync<T>(
            HttpClient httpClient,
            string queryItem,
            string queryParams)
        {
            var response = await httpClient.GetAsync($"{queryItem}?{queryParams}");
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                var objects = JsonConvert.DeserializeObject<IEnumerable<T>>(content);
                return (objects, response);
            }

            return (null, response);
        }

        public static  async Task JsonToYamlConversion()
        {
            var r = new StreamReader(@"actions\userDefinedFunctions\ERData.json");
            var deserializer = new DeserializerBuilder().Build();
            var yamlObject = deserializer.Deserialize(r);

            var spaceCreateDescriptions = await GetProvisionSampleTopology(r);

            var expConverter = new ExpandoObjectConverter();
            dynamic deserializedObject = JsonConvert.DeserializeObject<ExpandoObject>(File.ReadAllText(@"actions\userDefinedFunctions\ERData.json"), expConverter);

            var serializer = new YamlDotNet.Serialization.Serializer();
            string yaml = serializer.Serialize(deserializedObject);


        }

        public static async Task JsonToClass()
        {         
            var ERJSONObject = JsonConvert.DeserializeObject<ERJSonInput>(File.ReadAllText(@"actions\userDefinedFunctions\ERSource.json"));



            //find room data from above class
            List<SpaceDescription> rooms = new List<SpaceDescription>();
            SpaceDescription room;
            foreach (var floor in ERJSONObject.floors)
            {
                foreach (var _room in floor.rooms)
                {
                    room = new SpaceDescription();
                    room.name = _room.entityName;
                    room.type = "Room";
                    room.resources = null;
                    room.keystores = null;

                    List<DeviceDescription> devicesFloor = new List<DeviceDescription>();
                    foreach (var devices in _room.assets)
                    {
                        var device = new DeviceDescription();
                        device.name = devices.entityName;
                        device.hardwareId = Guid.NewGuid().ToString();

                        List<SensorDescription> sensors = new List<SensorDescription>();
                        foreach (var points in devices.points)
                        {
                            var sensor = new SensorDescription();
                            sensor.hardwareId = Guid.NewGuid().ToString();
                            sensor.dataType = points.customData[0].units;
                            sensors.Add(sensor);
                        }                        
                        device.sensors = sensors;

                        devicesFloor.Add(device);
                    }
                    room.devices = devicesFloor;


                }
            }

            IEnumerable<SpaceDescription> spaceCreateDescriptions;
            using (var r = new StreamReader("actions/provisionSample_OOTF_MultilevelRoom Schema.yaml"))
            {
                spaceCreateDescriptions = await GetProvisionSampleTopology(r);
            }


            var serialzer = new YamlDotNet.Serialization.Serializer();
            using (var write = new StringWriter())
            {
                serialzer.Serialize(write, ERJSONObject);
                var yaml = write.ToString();
            }
        }

        private static string GetDisplayValues(Models.Space space)
        {
            var spaceValue = space.Values.First(v => v.Type == "AvailableAndFresh");
            return $"Name: {space.Name}\nId: {space.Id}\nTimestamp: {spaceValue.Timestamp}\nValue: {spaceValue.Value}\n";
        }
    }
}