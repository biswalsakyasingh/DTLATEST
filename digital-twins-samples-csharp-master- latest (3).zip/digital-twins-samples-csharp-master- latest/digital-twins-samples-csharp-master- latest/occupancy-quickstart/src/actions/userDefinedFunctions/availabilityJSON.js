// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

// Add your sensor type here



function process(telemetry, executionContext)
{

    try
    {
        debugger
        // Log SensorId and Message
        log(`Sensor ID: ${telemetry.SensorId}. `);
        log(`Sensor value: ${JSON.stringify(telemetry.Message)}.`);

        // Get sensor metadata
        var sensor = getSensorMetadata(telemetry.SensorId);

        // Retrieve the sensor reading
        var parseReading = JSON.parse(telemetry.Message);

        // Set the sensor reading as the current value for the sensor.
        setSensorValue(telemetry.SensorId, sensor.DataType, parseReading.SensorValue);

        // Get parent space
        var parentSpace = sensor.Space();

        // Get children sensors from the same space
        var otherSensors = parentSpace.ChildSensors();

        var CAMERASensor = otherSensors.find(function (element) {
            return element.DataType === jsonType;
        });
        // Add your sensor variable here

        // get latest values for above sensors        
        var cameraValue = CAMERASensor.Value().Value;
        // Add your sensor latest value here

        // Return if no motion or carbonDioxide found return
        // Modify this line to monitor your sensor value
        if (cameraValue === null) {
            sendNotification(telemetry.SensorId, "Sensor", "Error: camera is not running, returning");
            return;
        }
        // Modify this code block for your sensor
        setSpaceValue(parentSpace.Id, "JSON", cameraValue);
    }
    catch (error) {
        log(`An error has occurred processing the UDF Error: ${error.name} Message ${error.message}.`);
    }
}

