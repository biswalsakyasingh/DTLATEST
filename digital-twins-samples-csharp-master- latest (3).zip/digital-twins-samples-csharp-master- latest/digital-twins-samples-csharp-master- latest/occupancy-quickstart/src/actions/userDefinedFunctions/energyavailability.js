// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

// Add your sensor type here


function process(telemetry, executionContext) {

    try {        
        // Log SensorId and Message
        log(`Sensor ID: ${telemetry.SensorId}. `);
        log(`Sensor value: ${JSON.stringify(telemetry.Message)}.`);

        // Get sensor metadata
        var sensor = getSensorMetadata(telemetry.SensorId);

        // Retrieve the sensor reading
        var parseReading = JSON.parse(telemetry.Message);

        // Set the sensor reading as the current value for the sensor.
        setSensorValue(telemetry.SensorId, sensor.DataType, parseReading.SensorValue);

        // Get parent space
        var parentSpace = sensor.Space();

        // Get children sensors from the same space
        var otherSensors = parentSpace.ChildSensors();

        // Retrieve carbonDioxide, and motion sensors
        var EnergySensor = otherSensors.find(function (element) {
            return element.DataType === energyconsumptionType;
        });
       
        // Add your sensor variable here

        // get latest values for above sensors
        var energyValue = EnergySensor.Value().Value;
        // Add your sensor latest value here

        // Return if no motion or carbonDioxide found return
        // Modify this line to monitor your sensor value
        if (energyValue === null) {
            sendNotification(telemetry.SensorId, "EnergyMeter", "Error: Energy readings  are null, returning");
            return;
        }

        // Modify this code block for your sensor
        setSpaceValue(parentSpace.Id, "EnergyMeter", energyValue);       
    }
    catch (error) {
        log(`An error has occurred processing the UDF Error: ${error.name} Message ${error.message}.`);
    }
}
