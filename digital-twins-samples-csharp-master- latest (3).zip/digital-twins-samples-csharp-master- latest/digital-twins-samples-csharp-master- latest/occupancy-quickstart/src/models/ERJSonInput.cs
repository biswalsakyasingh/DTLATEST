﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;

namespace Microsoft.Azure.DigitalTwins.Samples.models
{

    
    public class customData
    {
        [JsonIgnore]
        public string datatype { get; set; }
        [JsonIgnore]
        public string  units { get; set; }
        
    }
    public class points
    {
        public string id { get; set; }
        public string entityType { get; set; }
        public string entityName { get; set; }
        public string pointRole { get; set; }
        public List<customData> customData { get; set; }        
    }

    public class assets
    {
        public string id { get; set; }
        public string entityType { get; set; }
        public string entityName { get; set; }
        public List<points> points { get; set; }
    }
    public class rooms
    {
        public string id { get; set; }
        public string entityType { get; set; }
        public string entityName { get; set; }
        public List<assets> assets { get; set; }
    }
    public class floors
    {
        public string id { get; set; }
        public string entityType { get; set; }
        public string entityName { get; set; }
        public List<rooms> rooms { get; set; }
    }
    public class ERJSonInput
    {
        public string id { get; set; }
        public string entityType { get; set; }
        public string entityName { get; set; }
        public List<floors> floors { get; set; }
    }
}
