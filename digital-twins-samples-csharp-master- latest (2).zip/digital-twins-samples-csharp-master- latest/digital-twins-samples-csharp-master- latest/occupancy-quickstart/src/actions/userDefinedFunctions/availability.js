// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

// Add your sensor type here
var temperatureType = "Temperature";
var temperatureThreshold = 78;
var carbonDioxideType = "CarbonDioxide";
var motionType = "Motion";
var spaceAvailFresh = "AvailableAndFresh";
var carbonDioxideThreshold = 1000.0;


function process(telemetry, executionContext) {

    try {
        debugger
        // Log SensorId and Message
        log(`Sensor ID: ${telemetry.SensorId}. `);
        log(`Sensor value: ${JSON.stringify(telemetry.Message)}.`);

        // Get sensor metadata
        var sensor = getSensorMetadata(telemetry.SensorId);

        // Retrieve the sensor reading
        var parseReading = JSON.parse(telemetry.Message);

        // Set the sensor reading as the current value for the sensor.
        setSensorValue(telemetry.SensorId, sensor.DataType, parseReading.SensorValue);

        // Get parent space
        var parentSpace = sensor.Space();

        // Get children sensors from the same space
        var otherSensors = parentSpace.ChildSensors();

        // Retrieve carbonDioxide, and motion sensors
        var carbonDioxideSensor = otherSensors.find(function (element) {
            return element.DataType === carbonDioxideType;
        });

        var motionSensor = otherSensors.find(function (element) {
            return element.DataType === motionType;
        });

        var temperatureSensor = otherSensors.find(function (element) {
            return element.DataType === temperatureType;
        });

        var CAMERASensor = otherSensors.find(function (element) {
            return element.DataType === jsonType;
        });

        var PowerSensor = otherSensors.find(function (element) {
            return element.DataType === energyconsumptionType;
        });
        // Add your sensor variable here

        // get latest values for above sensors
        var motionValue = motionSensor.Value().Value;
        var presence = !!motionValue && motionValue.toLowerCase() === "true";
        var carbonDioxideValue = getFloatValue(carbonDioxideSensor.Value().Value);
        var temperatureValue = getFloatValue(temperatureSensor.Value().Value);
        var cameraValue = CAMERASensor.Value().Value;
        // Add your sensor latest value here

        // Return if no motion or carbonDioxide found return
        // Modify this line to monitor your sensor value
        if (temperatureValue === null) {
            sendNotification(telemetry.SensorId, "Sensor", "Error: temperature are null, returning");
            return;
        }

        // Modify these lines as per your sensor
        var alert = "Room with comfortable temperature is available.";
        var noAlert = "Either  room is occupied, or working conditions are not right.";

        // Modify this code block for your sensor

        setSpaceValue(parentSpace.Id, "JSON", cameraValue);

        // If carbonDioxide less than threshold and no presence in the room => log, notify and set parent space computed value
        // If sensor values are within range and room is available
        if (temperatureValue < temperatureThreshold) {
            log(`${alert}Temperature: ${temperatureValue}`);

            alert += temperatureValue;
            // log, notify and set parent space computed value
            setSpaceValue(parentSpace.Id, "Temperature", alert);

            // Set up notification for this alert
            parentSpace.Notify(JSON.stringify(alert));
        }
        else {
            log(`${noAlert} Temperature: ${temperatureValue}`);

            noAlert += temperatureValue;
            // log, notify and set parent space computed value
            setSpaceValue(parentSpace.Id, "Temperature", noAlert);
        }
    }
    catch (error) {
        log(`An error has occurred processing the UDF Error: ${error.name} Message ${error.message}.`);
    }
}

function getFloatValue(str) {
    if (!str) {
        return null;
    }

    return parseFloat(str);
}
