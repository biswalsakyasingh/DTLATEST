﻿[
    {
        "name": "Beeah-OOTF-Mainbuilding",
        "type": "Venue",
        "spaces": [
            {
                "name": "Ground Floor",
                "type": "Floor",
                "spaces": [
                    {
                        "name": "East Zone",
                        "type": "Area",
                        "spaces": [
                            {
                                "name": "Confernece Room"
                            },
                            {
                                "type": "Room",
                                "subType": "ConferenceRoom",
                                "devices": [
                                    {
                                        "name": "Energy_Meter",
                                        "hardwareId": "9eb52f54-87e4-4535-9691-243e00055fbb",
                                        "sensors": [
                                            {
                                                "dataType": "EnergyConsumption",
                                                "hardwareId": "ENERGY_SENSOR_DEMAND"
                                            },
                                            {
                                                "dataType": "EnergyConsumption",
                                                "hardwareId": "ENERGY_SENSOR_CONSUMPTION"
                                            }
                                        ]
                                    }
                                ],
                                "matchers": [
                                    {
                                        "name": "Matcher EnergyConsumption",
                                        "dataTypeValue": "EnergyConsumption"
                                    }
                                ],
                                "userdefinedfunctions": [
                                    {
                                        "name": "EnergyConsumption Processor",
                                        "matcherNames": [
                                            "Matcher EnergyConsumption"
                                        ],
                                        "script": "actions/userDefinedFunctions/energyavailability.js"
                                    }
                                ],
                                "roleassignments": [
                                    {
                                        "roleId": "98e44ad7-28d4-4007-853b-b9968ad132d1",
                                        "objectName": "EnergyConsumption Processor",
                                        "objectIdType": "UserDefinedFunctionId"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    }
]